#ifndef SCANBALANCE_H
#define SCANBALANCE_H

#include "distribution.h"

void GetAddressBalances(unsigned int cutoffTime, BalanceMap& mapBalance);

#endif

qmake "USE_QRCODE=1" "USE_UPNP=1" "USE_IPV6=1" ybcoin_pos-windows.pro
mingw32-make -f Makefile.Release